import imp , copy, time
import os
import sys
import json
import traceback
import logging
import base64
import datetime
logging.basicConfig(level=logging.DEBUG)
import uuid

current_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(current_dir, "../dependencies"))
print("current directory", current_dir)

import azure.functions as func
from azure.identity import ClientSecretCredential, EnvironmentCredential, DefaultAzureCredential, ManagedIdentityCredential, VisualStudioCodeCredential
from azure.mgmt.eventgrid import EventGridManagementClient
from azure.mgmt.eventgrid.models._models_py3 import SystemTopic
from azure.mgmt.eventgrid.operations import EventSubscriptionsOperations
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.eventgrid.models import Topic
from azure.mgmt.alertsmanagement import AlertsManagementClient
from azure.cosmos import database
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.monitor.models import RuleMetricDataSource, RuleDataSource
from azure.mgmt.monitor.models import ThresholdRuleCondition
from azure.mgmt.monitor.models import RuleEmailAction 
from azure.cosmos import CosmosClient, PartitionKey, ConsistencyLevel
from azure.storage.blob import BlobServiceClient
from azure.keyvault.secrets import SecretClient

# Key vault name
KEYVAULT_NAME = "cm-app-keyvault-dev"

def get_keyvault_secret(secret_name: str) -> str:
    """get secrets from key vaults

    Args:
        secret_name (str): _description_

    Returns:
        str: _description_
    """
    try: 
        # Use Managed Identity or set credentials as needed
        m_credential =  DefaultAzureCredential(managed_identity_client_id="2017d6f9-0450-48ef-bb90-70e5ecbed375")
        secret_client = SecretClient(vault_url=f"https://{KEYVAULT_NAME}.vault.azure.net", credential=m_credential)
        secret = secret_client.get_secret(secret_name).value
        return secret
    except Exception as e:
        post_slack("secret", 'Error getting secret from Key Vault', traceback.format_exc())
        return ""

LOCATION = 'westus2'
GROUP_NAME = 'cloud-monitoring'
TOPIC_NAME = "cloudmonitoringtest1"
subscription_id = get_keyvault_secret("SubscriptionId")
HOST = 'https://cm-app-global-dev.documents.azure.com:443/'
MASTER_KEY = get_keyvault_secret("MasterKey")
client_id=get_keyvault_secret("ClientId")
client_secret = get_keyvault_secret("clientSecret")
tenant_id=get_keyvault_secret("TenantId")
event_grid_access_key = get_keyvault_secret("EventGridAccessKey")
event_grid_topic_endpoint = "https://cm-app-testing-grid-topic.westus2-1.eventgrid.azure.net/api/events"
blob_account = "https://cmappexistingstoragedev.blob.core.windows.net"
blob_container = "cmappstoragecontainerexistingdev"
blob_key = get_keyvault_secret("BlobKey")
credential = ClientSecretCredential(
    client_id=client_id,
    client_secret=client_secret,
    tenant_id=tenant_id
)
cosmos_client = dbclient = CosmosClient(HOST, {'masterKey': MASTER_KEY}, ConsistencyLevel.Eventual )
alerts_client = AlertsManagementClient(credential, subscription_id)
monitor_client = MonitorManagementClient(credential, subscription_id)
event = custom_schema_event = {
    "customSubject": "sample",
    "customEventType": "sample.event",
    "customDataVersion": "2.0",
    "customId": uuid.uuid4(),
    "customEventTime": "2022-12-01T21:14",
    "customData": "sample data"
    }
alarm_id = {
    "VirtualMachine": "virtual_machine",
    "DatabaseAccounts":"database",
    "FunctionApp":"function",
    "StorageAccounts":"storage",
    "VirtualMachineScaleSets":"vmscaleset"
}

def main(req):

    logging.info('Python trigger processing an event')
    run(req.get_json())
    logging.info('Python trigger processed an event')
    return func.HttpResponse('ok', status_code=200)

def run(req):
    blob_service_client = BlobServiceClient(
        account_url=blob_account,
        credential=blob_key
    )
    logging.info(req["blob"])
    logging.info("the configuration recieven inside the put alarm function is")
    logging.info(req['configuration'])
    logging.info(req["tags"])
    alarm_dimensions(download_blob(blob_service_client,req["blob"],cosmos_client,monitor_client),get_record(cosmos_client, monitor_client, req['configuration']),req['subscription_id'],req["tags"],cosmos_client)

def list_alarms(client):
    """listing alarms

    Args:
        client (_type_): _description_
    """
    alerts = client.metric_alerts.list_by_subscription()
    logging.info('alerts:-')
    if not alerts:
        logging.info('No alerts found')
        return
    for alert in alerts:
        logging.info(alert)
    print("alerts_printing..")
    print(str(alerts))

def create_alarms(client, resource_group, rule_name):
    """creating alarms ufsing python module

    Args:
        client (_type_): _description_
        resource_group (_type_): _description_
        rule_name (_type_): _description_
    """
    parameters = create_alert_parameters()
    alerts = client.metric_alerts.create_or_update(
        resource_group_name =resource_group,
        rule_name=rule_name,
        parameters=parameters
    )
    if not alerts:
        logging.info("alerts creation failed..")
        return
    else:
        logging.info("alerts created ..")
        logging.info(alerts)
        return

def delete_alarms(client, resource_group, rule_name):
    """delete alarm function

    Args:
        client (_type_): _description_
        resource_group (_type_): _description_
        rule_name (_type_): _description_
    """
    alerts = client.metric_alerts.delete(
        resource_group_name =resource_group,
        rule_name=rule_name
    )
    if not alerts:
        logging.info("alerts creation failed..")
        return
    else:
        logging.info("alerts created ..")
        logging.info(alerts)
        return

def list_databases(client):
    """listing the database

    Args:
        client (_type_): _description_
    """
    logging.info('Databases:-')
    databases = list(client.list_databases())
    if not databases:
        logging.info('No Database found')
        return
    for database in databases:
        logging.info(database['id'])

def delete_record(client, name):
    """method for deleting record form database

    Args:
        client (_type_): _description_
        name (_type_): _description_
    """

    item = {
    "id": "123456789"}
    database = client.get_database_client({"id":name})
    for container in database.list_containers():
       print("Container ID: {}".format(container['id']))
    container = database.get_container_client({"id":"test"})

    response = container.delete_item(item=item,partition_key="61dba35b-4f02-45c5-b648-c6badc0cbd79")

    if not response:
        logging.info("request didnt processed")
        return
    else:
        logging.info("response recieved from the database deletion")
        logging.info(response)
        return

def create_alert_parameters(alarm, resource,subscription_id):
    """creating alert paramters for azure to create alerts

    Args:
        alarm (_type_): _description_
        resource (_type_): _description_
        subscription_id (_type_): _description_

    Returns:
        _type_: _description_
    """

    defaults = {
        'type': 'alert',
        'evaluationFrequency': '5m',
        'threshold': 0,
        'metricNamespace': 'defaultNamespace',
        'metricName': 'defaultMetric',
        'operator': 'equals',
        'timeAggregation': 'sum',
        'targetResourceType': 'defaultResourceType',
        'targetResourceRegion': 'defaultRegion'
    }

    # Create a dictionary with updated/default values using dictionary comprehension
    alarm_with_defaults = {key: alarm.get(key, default) for key, default in defaults.items()}

    parameters = {
        "type": alarm_with_defaults['type'],
        "apiVersion": "2018-03-01",
        "name": "",
        "location": "global",
        "severity": 1,
        "enabled": True,
        "scopes": [resource['id']],
        "evaluationFrequency": alarm_with_defaults['evaluationFrequency'],
        "windowSize": alarm.get('windowSize', ''),  # This assumes a default empty string if 'windowSize' is not in alarm
        "criteria": {
            "allOf": [
                {
                    "threshold": alarm_with_defaults['threshold'],
                    "name": "Metric1",
                    "metricNamespace": alarm_with_defaults['metricNamespace'],
                    "metricName": alarm_with_defaults['metricName'],
                    "operator": alarm_with_defaults['operator'],
                    "timeAggregation": alarm_with_defaults['timeAggregation'],
                    "skipMetricValidation": False,
                    "criterionType": "StaticThresholdCriterion"
                }
            ],
            "odata.type": "Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria"
        },
        "autoMitigate": True,
        "targetResourceType": alarm_with_defaults['targetResourceType'],
        "targetResourceRegion": alarm_with_defaults['targetResourceRegion'],
        "actions": [
            {
                        "actionGroupId": f"/subscriptions/{subscription_id}/resourceGroups/cloud-monitoring/providers/microsoft.insights/actiongroups/cloud-monitoring-global-action-group",
                        "webHookProperties": {}
                    }
        ]
    }

    return parameters

def get_record(client, monitor_client, configuration):
    """function to fetch a specific record from cosmosdb.

    Args:
        container (_type_): _description_
        item (_type_): _description_
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        database = client.get_database_client({"id":"configuration"})
        for container in database.list_containers():
            print("Container ID: {}".format(container['id']))
        container = database.get_container_client({"id":"Items"})
        response = container.read_item(item=configuration, partition_key=configuration)
        if not response:
            logging.info("request didnt processed")
            return
        else:
            return response
    except Exception:
            post_slack(
            "secret", 'Failed toread item the error', traceback.format_exc())
   
def download_blob(blob_client, blob_name, cosmos_client, monitor_client):
    """ method for downloading blob for alerts creation

    Args:
        blob_client (_type_): _description_
        blob_name (_type_): _description_
        cosmos_client (_type_): _description_
        monitor_client (_type_): _description_

    Returns:
        _type_: _description_
    """
    container = blob_client.get_container_client(blob_container)
    logging.info('in blob container call..')
    logging.info(container)
    response = container.download_blob(blob=blob_name)
    data = json.loads(response.readall().decode('utf-8'))
    logging.info(data)
    return data

def insert_alarm_record(client, container, data,subscription_id, alarm_name, severity,tags):
    """function facilitates the record insertion in the alarms container.

    Args:
        client (_type_): _description_
        name (_type_): _description_
        subscription (_type_): _description_
    """
    new_item = create_alarm_record(data,subscription_id, alarm_name, severity,tags)
    try:
        logging.info("inside db writing..")
        logging.info(new_item)
        database = client.get_database_client({"id":container}) 
        container = database.get_container_client({"id":"Items"})
        response = container.upsert_item(new_item)
        if not response:
            logging.info("account insertion to database failed")
            return
        else:
            logging.info(response)
            return
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc())

def alarm_dimensions(data, configuration,subscription_id,tags,cosmos_client):
    """creating alarm dimentions

    Args:
        data (_type_): _description_
        configuration (_type_): _description_
        subscription_id (_type_): _description_
        tags (_type_): _description_
    """
    logging.info("inside the alarm dimentions.")
    data = json.loads(data)
    logging.info(data.keys())
    for key in (data.keys()):    
        dimensions = set()   
        if key in ("VirtualMachine","FunctionApp","DatabaseAccounts","VirtualMachineScaleSets"):
            resource_count=0
            logging.info('Info: Alarms for......')
            logging.info(key)
            for resource in data[key]:
                logging.info(resource['id'])
                logging.info(resource_count)
                if resource_count <1:
                    defination = configuration['configuration']['M'][key]['defination']
                    # print('Info: Definitions: for the key ', defination)
                    for d in defination:
                        if d['math_exp'] == 'none':
                            if 'dimensions' in d:
                                dimensions.update(d['dimensions'])
                        else:
                            for mk in d['metrics'].keys(): 
                                if 'dimensions' in d['metrics'][mk]:
                                    dimensions.update(d['metrics'][mk]['dimensions'])
                        if 'conditions' in d: 
                            dimensions.update([item['key'] for condition in d['conditions']
                                            for item in d['conditions'][condition]])
                            
                    res = extended_extract_values(data[key], dimensions, key)   
                    create_alarm(defination, key, resource,subscription_id, tags)
                    resource_count +=1
    sub_id=subscription_id+'-'+base64.b64encode((tags['key']+tags['value']).encode('utf-8')).decode('utf-8')
    logging.info("the sub id generated.")
    logging.info(sub_id)
    database = cosmos_client.get_database_client({"id":'account'})
    container = database.get_container_client({"id":"Items"})
    query = f"SELECT * FROM c WHERE c.id ='{sub_id}'"
    response = list(container.query_items(query, enable_cross_partition_query=True))[0]
    logging.info("updating status of the account table after onboarding...")
    if response:
        response['status'] = "completed"
        container.upsert_item(response)

def create_alarm(definition, key, resource,subscription_id,tags):
    """create azure alert

    Args:
        definition (_type_): _description_
        key (_type_): _description_
        resource (_type_): _description_
        subscription_id (_type_): _description_
        tags (_type_): _description_
    """
    count = 0
    for alert in definition:
        if alert:
            gen_alarm_metric(alert, key, resource,subscription_id,tags)
            count += 1
    return

def gen_alarm_name(alarm, key, resource, subscription_id,tags):
    """create alert unique name

    Args:
        alarm (_type_): _description_
        key (_type_): _description_
        resource (_type_): _description_

    Raises:
        Exception: _description_

    Returns:
        _type_: _description_
    """
    name = alarm['metricName']
    resource_name = resource['id'][resource['id'].rindex('/')+1:len(resource['id'])]
    base64encoded = subscription_id+'-'+base64.b64encode((tags['key']+tags['value']).encode('utf-8')).decode('utf-8')
    try:
        return f'yeti||global||{key}||{name}||1.0||{subscription_id}||{resource_name}'
    except Exception:
        raise Exception('Invalid Name')
    
def alarm_def(alert, alarm_name, key, resource):
    """create alarm definitions.

    Args:
        alert (_type_): _description_
        alarm_name (_type_): _description_
        key (_type_): _description_
        resource (_type_): _description_

    Returns:
        _type_: _description_
    """
    alerts=[]
    alert['name'] = alarm_name
    alert['scope'] = [resource['id']]
    logging.info(alert['name'])
    alerts_response = monitor_client.metric_alerts.create_or_update(
        resource_group_name ="cloud-monitoring",
        rule_name=alert['name'],
        parameters=alert
    )
    alerts.append(alerts_response)
    logging.info(alerts)

    if not alerts_response:
        logging.info("alerts creation failed..")
        logging.info(alerts_response)
        return
    else:
        print("alarm created")
        logging.info(alarm_name)
    return alerts_response

def gen_alarm_metric(alarm, key, resource,subscription_id,tags):
    """method to create alarm metric 

    Args:
        alarm (_type_): _description_
        key (_type_): _description_
        resource (_type_): _description_
        subscription_id (_type_): _description_
        tags (_type_): _description_

    Returns:
        _type_: _description_
    """
    if 'conditions' in alarm:
        if 'and' in alarm['conditions'] and False in check_condition(alarm['conditions']['and'], resource):
            logging.info('Info: Condition AND Failed of alarm')
            logging.info(alarm['metric'])
            logging.info(resource)
            return
        if 'or' in alarm['conditions'] and True not in check_condition(alarm['conditions']['or'], resource):
            logging.info('Info: Condition OR Failed of alarm')
            logging.info(alarm['metric'])
            logging.info(resource)
            logging.info("checking conditions...")
    alarm_metric = create_alert_parameters(alarm, resource, subscription_id)
    try:
        alarm_name = gen_alarm_name(alarm, key, resource,subscription_id,tags)
        response = alarm_def(alarm_metric, alarm_name, key, resource)
        db_response = insert_alarm_record(cosmos_client, "alarms", alarm, subscription_id, alarm_name,alarm_metric['severity'],tags)
        return response
    except Exception as e:
        print("error in the gen alarm metric")
            
def check_condition(alarm_conditions, data):
    """check conditions

    Args:
        alarm_conditions (_type_): _description_
        data (_type_): _description_

    Returns:
        _type_: _description_
    """
    res = set()
    try:
        for item in alarm_conditions:
            if item['operator'] == '==':
                res.add(data[item['key']] == item['value'])
            elif item['operator'] == 'in':
                res.add(item['value'] in data[item['key']])
            elif item['operator'] == '!=':
                res.add(data[item['key']] != item['value'])
            elif item['operator'] == 'startswith':
                res.add(data[item['key']].startswith(item['value']))
    except Exception:
        pass
        post_slack('Failed to find condition key in data',
                   traceback.format_exc())
        res.add(False)
    return res

def extended_extract_values(obj, dimensions, id):
    """unwrapping son object from nested structures

    Args:
        obj (_type_): _description_
        dimensions (_type_): _description_
        id (_type_): _description_

    Returns:
        _type_: _description_
    """
    arr = [{}]
    for item in obj:
        if arr[-1]:
            arr.append({})
        extract(item, arr, [k.lower() for k in dimensions], id)
    return arr

def extract(obj, arr, keys, id):
    """unwrapping json from nested structures

    Args:
        obj (_type_): _description_
        arr (_type_): _description_
        keys (_type_): _description_
        id (_type_): _description_

    Returns:
        _type_: _description_
    """
    alarm_ids = [k.lower() for k in alarm_id[id].split(',')]
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, list):
                if k.lower() in keys:
                    x = arr[-1]
                    for item in v:
                        arr[-1] = copy.deepcopy(x)
                        arr[-1][k] = item
                        arr.append({})
                else:
                    extract(v, arr, keys, id)
            elif k.lower() in keys or k.lower() in alarm_ids:
                arr[-1][k] = v
            elif isinstance(v, dict):
                extract(v, arr, keys, id)
    elif isinstance(obj, list):
        for item in obj:
            extract(item, arr, keys, id)
    return arr

def create_alarm_record(data,subscription_id, alarm_name,severity,tags):
    """creating alarm record in cosmos db

    Args:
        data (_type_): _description_
        subscription_id (_type_): _description_
        alarm_name (_type_): _description_
        severity (_type_): _description_
        tags (_type_): _description_

    Returns:
        _type_: _description_
    """
    defaults = {
        'type': 'alert',
        'evaluationFrequency': '5m',
        'threshold': 0,
        'metricNamespace': 'defaultNamespace',
        'metricName': 'defaultMetric',
        'operator': 'equals',
        'timeAggregation': 'sum',
        'targetResourceType': 'defaultResourceType',
        'targetResourceRegion': 'defaultRegion',
        'alarm_description': "",
        'priority':''
    }
    
    # Create a dictionary with updated/default values using dictionary comprehension
    alarm_with_defaults = {key: data.get(key, default) for key, default in defaults.items()}

    parameters = {
        'id': alarm_name,
        'alarm_name': f'/subscriptions/{subscription_id}/resourceGroups/cloud-monitoring/providers/Microsoft.Insights/metricAlerts/{alarm_name}',
        'alarm_threshold':alarm_with_defaults['threshold'],
        'alarm_description': alarm_with_defaults['alarm_description'],
        'subscription_id': subscription_id+'-'+base64.b64encode((tags['key']+tags['value']).encode('utf-8')).decode('utf-8'),
        'priority':alarm_with_defaults['priority'],
        'is_deleted': False
        # for future use.
        # 'metricName': alarm_with_defaults['metricName'],
        # 'operator': alarm_with_defaults['operator'],
        # 'timeAggregation': alarm_with_defaults['timeAggregation'],
        # 'metricNamespace': alarm_with_defaults['metricNamespace'],
        # 'evaluationFrequency': alarm_with_defaults['evaluationFrequency'],
        # 'targetResourceRegion': alarm_with_defaults['targetResourceRegion'],
        # 'type': alarm_with_defaults['type'],
        # 'resource_id':[resource['id']]
        #  Can be used later if more innformation about the alerts are required in the table
        # ':empty_audit': [],
        # ':audit': [json.dumps(data)]  # removed cls=DecimalEncoder for simplicity, reintroduce if needed
    }
    return parameters

class DecimalEncoder(json.JSONEncoder):
    """Class for converting ItemPaged object to json.

    Args:
        json (_type_): _description_
    """
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.timestamp()
        return obj.__dict__ 

def post_slack(secret, msg, e):
    """function pushes errors to slack as a part of user notification.

    Args:
        secret (_type_): _description_
        msg (_type_): _description_
        e (_type_): _description_
    """
    # print('Error:' if e else 'Info:', msg, e)
    # url = secret.get('slack_url')
    # headers = {
    #     'x-api-key':  secret.get('slack_key'),
    #     'content-type': 'application/json'
    # }

    # pld = {
    #     'status': 'failed' if e else 'ok',
    #     'impacted_area': f'{os.environ.get("FUNCTION")} || {msg}',
    #     'description': str(e),
    #     'slack': secret.get('slack_channel'),
    #     'dpe_division': 'des'
    # }
    # r = requests.post(url, data=json.dumps(pld), headers=headers)
    # print('Info: Error posted to slack', r.status_code)
    print("the error raised. ",e)