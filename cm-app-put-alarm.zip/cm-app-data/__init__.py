# deployment
import os
import sys
import json
import traceback
import base64
import logging
import asyncio
from urllib import response
from urllib.parse import urlparse, parse_qs
import requests
from datetime import datetime
import azure.functions as func
current_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(current_dir, "dependencies"))
from concurrent.futures import ThreadPoolExecutor
import azure.functions as func
from azure.cosmos import CosmosClient, ConsistencyLevel, exceptions
from azure.mgmt.eventgrid import EventGridManagementClient
from azure.identity import ClientSecretCredential, DefaultAzureCredential, ManagedIdentityCredential
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.resource import ResourceManagementClient
from azure.keyvault.secrets import SecretClient

# Key vault name
KEYVAULT_NAME = "cm-app-keyvault-dev"

def get_keyvault_secret(secret_name: str) -> str:
    """get secrets from key vaults

    Args:
        secret_name (str): _description_

    Returns:
        str: _description_
    """
    try: 
        # Use Managed Identity or set credentials as needed
        m_credential =  DefaultAzureCredential(managed_identity_client_id="2017d6f9-0450-48ef-bb90-70e5ecbed375")
        logging.info("the default credentials...")
        logging.info(str(m_credential))
        secret_client = SecretClient(vault_url=f"https://{KEYVAULT_NAME}.vault.azure.net", credential=m_credential)
        secret = secret_client.get_secret(secret_name).value
        return secret
    except Exception as e:
        post_slack("secret", 'Error getting secret from Key Vault', traceback.format_exc())
        return ""


LOCATION = 'West US 2'
GROUP_NAME = 'cloud-monitoring-dev'
TOPIC_NAME = "cloudmonitoringtest1"
HOST = 'https://cm-app-global-dev.documents.azure.com:443/'
# MASTER_KEY = get_keyvault_secret("MasterKey")
# app_alert_no_token = "https://cm-app-existing-resource-dev.azurewebsites.net/api/cm-app-alarms?"
# app_alert_function_key = get_keyvault_secret("AppalertFunctionKey")
# app_list_services = "https://cm-app-existing-resource-dev.azurewebsites.net/api/cm-app-list-services?"
# app_list_function_key = get_keyvault_secret("AppListServices")
# client_id=get_keyvault_secret("ClientId")
# client_secret = get_keyvault_secret("clientSecret")
# tenant_id=get_keyvault_secret("TenantId")
# subscription_id = get_keyvault_secret("SubscriptionId")
# allowed_resources = {"VirtualMachine","FunctionApp","DatabaseAccounts","VirtualMachineScaleSets"}
# credential = ClientSecretCredential(
#     client_id=client_id,
#     client_secret=client_secret,
#     tenant_id=tenant_id
# )
# event_grid_access_key = get_keyvault_secret("EventGridAccessKey")
event_grid_topic_endpoint = "https://cm-app-testing-grid-topic.westus2-1.eventgrid.azure.net/api/events"
header = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,Accept'
}

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python trigger processing an event')
    # secret = get_keyvault_secret("clientSecret")
    # status_code,status = run(req) 
    logging.info('Python trigger processed an event')

    return func.HttpResponse(status_code=200, body=json.dumps({'status':"status" }))

def run(req):
    """
    function to create client credentials and azure resource clients.

    Args:
        req (_type_): function input.
    """
    logging.info("function invoked with the input..")
    logging.info(str(req))
    

    credential = ClientSecretCredential(
    client_id=client_id,
    client_secret=client_secret,  
    tenant_id=tenant_id
    )
    dbclient = CosmosClient(HOST, {'masterKey': MASTER_KEY}, ConsistencyLevel.Eventual )
    monitor_client = MonitorManagementClient(credential, subscription_id)
    resource_group_client = ResourceManagementClient(credential, subscription_id)

    parsed_url = urlparse(req.url)
    http_method = req.method
    logging.info(http_method)
    logging.info(parsed_url)

    if http_method == 'POST':
        path = parsed_url.query.split('&')[1]
        logging.info(path)
        status_code, status = post(path, req, dbclient, resource_group_client)
        return status_code, status

    if http_method == 'PUT':
        try:
            path = parsed_url.query.split('&')[1]
        except IndexError:
            path = parsed_url.query
        logging.info(path)
        status_code, status = put(path,req,dbclient, monitor_client)
        return status_code, status

    if http_method == 'DELETE':
        path = parsed_url.query.split('&')[1]
        logging.info(path)
        status_code, status = delete(path,req, dbclient, resource_group_client)
        return status_code, status

    elif http_method == 'GET':
        path = parsed_url.query.split('?')[0].split('&')[1]
        logging.info(path)
        status_code, status = get(path,req, dbclient)
        return status_code, status

def get(path, req, client):
    """function to handle get request recieved.

    Args:
        path (_type_): _description_
        req (_type_): _description_
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    if path == '/alarms':
        return 200, get_alerts(client,"alarms", req)
    if path == '/configuration':
        return 200, get_configuration(client,req)
    if path == '/account/detail':
        return 200, get_record(client,"account", req)
    if path == '/threshold-configuration':
        return 200, threshold_configuration(client, req)
    elif path == "/resync-alarm":
        parsed_url = urlparse(req.url)
        id = parsed_url.query.split('id=')[1] if parsed_url.query else None
        mclient = MonitorManagementClient(credential,id)
        return  200, list_all_alerts(mclient)
    
def post(path, req, database, resource_group_client):
    """handles post request.

    Args:
        path (_type_): _description_
        req (_type_): _description_
        eventgrid (_type_): _description_
        database (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = req.get_json() if req.get_json() else req.body
    if 'tag_conditions' in data:
        if 'key' in data['tag_conditions']:
            tag_key = data['tag_conditions']['key']
        else:
            tag_key = None  
        if 'value' in data['tag_conditions']:
            tag_value = data['tag_conditions']['value']
        else:
            tag_value = None
    else:
        tag_key = None
        tag_value = None
    if path == "/account":
        logging.info("inside account-detail..")
        response = list_resource_group(resource_group_client)
        if response is True:
            db_process = insert_account_record(database, "account", data)
            if db_process is True:
                if data['existing_alarm'] == "true":
                    logging.info("calling app alert function for durther proccecing.")
                    # asyncio.ensure_future(call_app_list_alarms(subscription_id=data["subscription_id"]))
                    # loop.run_in_executor(None, schedule_async_function, loop, data)
                    # with ThreadPoolExecutor() as executor:
                    #     executor.submit(asyncio.run, call_app_list_alarms(subscription_id=data["subscription_id"]))
                    call_app_list_alarms(subscription_id=data["subscription_id"],tag_key=tag_key,tag_value=tag_value, conf=data['alarm_configuration'])
                    return 201, "account onboarding completed"
            elif db_process is False:
                return 200, "Account with this tag already already onboarded"
    elif path == '/accounts':
        return 200, list_accounts(database, data)
    elif path == '/alarms/sync':
        return 200, update_alarms_for_resync(database, data)
    else:
        return 200, "No valid path"
           
def put(path,req,dbclient, monitor_client):
    """handles put request

    Args:
        path (_type_): _description_
        req (_type_): _description_
        dbclient (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = req.get_json() if req.get_json() else req.body
    if path == "/alarms":
        return update_alarms(dbclient, data)
    elif path == '/account':
        return update_account(dbclient,data)

def delete(path,req,dbclient,resource_group_client):
    """handles delete requests

    Args:
        path (_type_): _description_
        req (_type_): _description_
        dbclient (_type_): _description_

    Returns:
        _type_: _description_
    """
    response = list_resource_group(resource_group_client)
    data = req.get_json() if req.get_json() else req.body
    if response is True:
        if path == "/alarms":       
                return delete_record(data["subscription_id"],dbclient,"alarms", data)
        elif path == '/accounts':
            return delete_account(data["subscription_id"],dbclient,"account", data)
    else:
        return "connection to the supscription failed with an error", response
        
def onboard_account(client):
    """onboard account function to try create event grid and its subscription to facilitate account onboarding.

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        event_grid_response = create_event_grid(client)
        subscription_respose = create_event_grid_subscption(client)
    except Exception:
            post_slack(
            "secret", 'Failed to onboard account with the error', traceback.format_exc())
    return subscription_respose

def update_account(client,req):
    """function to update a existing record on the account container

    Args:
        client (_type_): _description_
        item (_type_): _description_

    Returns:
        _type_: _description_
    """
    if response:
        try:
            database = client.get_database_client({"id":"account"})
            container = database.get_container_client({"id":"Items"})
            existing_data = container.read_item(item=req['id'], partition_key=req['id'])
            destination = ''
            if not existing_data:
                return 200, "account upadte failed with db error."
            
            # updated_data = {**existing_data, **req}

            if 'priority' in req and req['priority']:
                existing_data['priority'] = req['priority']
            else:
                if 'priority' in existing_data:
                    del existing_data['priority']
            if 'configuration_item' in req and req['configuration_item']:
                existing_data['configuration_item'] = req['configuration_item']
                destination += 'snow'
            else:
                if 'configuration_item' in existing_data:
                    del existing_data['configuration_item']
            if req.get('sys_id'):
                existing_data['sys_id'] = req.get('sys_id')

            if 'slack_channel' in req and req['slack_channel']:
                existing_data['slack_channel'] = req['slack_channel']
                destination += ',slack' if destination else 'slack'
            else:
                if 'slack_channel' in existing_data:
                    del existing_data['slack_channel']

            if 'pagerduty' in req and req['pagerduty']:
                existing_data['pagerduty'] = req['pagerduty']
                destination += ',pagerduty' if destination else 'pagerduty'
            else:
                if 'pagerduty' in existing_data:
                    del existing_data['pagerduty']

            if req.get('email'):
                existing_data['email'] = req.get('email')
                destination += ',email' if destination else 'email'
            if req.get('serviceId'):
                existing_data['serviceId'] = req.get('serviceId')

            if 'runbook_url' in req and req['runbook_url']:
                existing_data['runbook_url'] = req['runbook_url']
            else:
                if 'runbook_url' in existing_data:
                    del existing_data['runbook_url']
        
            if 'delegates' in req and req['delegates']:
                existing_data['delegates'] = req['delegates']
            else:
                if 'delegates' in existing_data:
                    del existing_data['delegates']

            if req.get('alarm_thresholds'):
                existing_data['alarm_thresholds'] = req.get('alarm_thresholds')

            if req.get('auto_remediation'):
                existing_data['auto_remediation'] = req.get('auto_remediation')

            if destination :
                existing_data['destination'] = destination
            else:
                del existing_data['destination']

            if req['alarm_configuration']!= existing_data['alarm_configuration']:
                logging.info("inside the alarm configuration change..")
                existing_data['alarm_configuration'] = req['alarm_configuration']
                delete_account(req['id'],client,'account',req={})
                call_app_list_alarms(req['subscription_id'],tag_key=req["tag_conditions"]["key"],tag_value=req["tag_conditions"]["value"],conf=req['alarm_configuration'])

            if not existing_data["existing_alarm"]:
                logging.info("inside adding existing alarms..")
                if req['existing_alarm']:
                    existing_data['existing_alarm'] = req['existing_alarm']
                    call_app_list_alarms(req['subscription_id'],tag_key=req["tag_conditions"]["key"],tag_value=req["tag_conditions"]["value"],conf=req['alarm_configuration'])
            
            if not req["existing_alarm"]:
                logging.info(existing_data['existing_alarm'])
                logging.info(req['existing_alarm'])
                existing_data['existing_alarm'] = req['existing_alarm']
                delete_account(req['id'],client,'account',req={})

            logging.info("the data after updation is ........")
            logging.info(existing_data)
            # Re-upload the updated data to Cosmos DB
            container.upsert_item(body=existing_data)
            if req.get('update_alarm'):
                logging.info("inside update alarm cofiguraton... set to true..")
                update_account_threshold_configuration(client, existing_data)

            

            return 200, "success"
        except Exception:
                post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def update_account_threshold_configuration(client, existing_data):
    """handles alarms updation if the threshold changes

    Args:
        path (_type_): _description_
        req (_type_): _description_
        dbclient (_type_): _description_

    Returns:
        _type_: _description_
    
    """
    logging.info("inside update alert threshold..")
    payload = {}
    alarms_database = client.get_database_client({"id":"alarms"})
    alarm_container = alarms_database.get_container_client({"id":"Items"})
    query =f"""
            SELECT * FROM c WHERE c.subscription_id = '{existing_data['id']}' AND c.is_deleted = false
            """
    logging.info(query)
    alarms_list = list(alarm_container.query_items(query, enable_cross_partition_query=True))
    logging.info("the length of the alarms fetched...")
    logging.info(len(alarms_list))
    
    for resource in existing_data['alarm_thresholds']:
        for alarm in existing_data['alarm_thresholds'][resource]:
            resourcename = f'{resource}||{alarm}'
            logging.info(resourcename)
            for _alarm in alarms_list:
                if resourcename in _alarm['id']:
                    payload[_alarm['id']] = existing_data['alarm_thresholds'][resource][alarm]['1.0']
                    _alarm['alarm_threshold'] = existing_data['alarm_thresholds'][resource][alarm]['1.0']
                    alarm_container.upsert_item(_alarm)
    logging.info("the payload created.......................")
    logging.info(payload)
    call_app_alert(existing_data['subscription_id'],data=payload,type="update-configuration")
    return "success"

def list_accounts(client, data):
    """function to fetch the available active records in the acccount container

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        database = client.get_database_client({"id":"account"}) 
        for container in database.list_containers():
            container = database.get_container_client({"id":"Items"})
            logging.info("list of avaiable accounts in the database.")

            dl = data['dl']
            email = data['user']['emailAddress']
            user_id = data['user']['userName']
            dl_values = [item['dl'] for item in dl]
            
            filter_exp = "(c.created_by = '"+email+"' OR ARRAY_CONTAINS(c.delegates.selected_users,{'emailAddress':'"+user_id+"'},true)"
            for index, dl_value in enumerate(dl_values):
                filter_exp += f" OR ARRAY_CONTAINS(c.delegates.dl, '{dl_value}')"

            filter_exp += ") AND c.is_deleted = false"

            # Query the container
            query = f"SELECT * FROM c WHERE {filter_exp}"

            logging.info("query_created")
            logging.info(query)

            response = list(container.query_items(query, enable_cross_partition_query=True))

        if not response:
            logging.info("request didnt processed")
            return
        else:
            logging.info("response recieved from the database insertion")
            for item in response:
                logging.info("the current item")
                logging.info(item)
            return response
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc())

def list_databases(client):
    """function to fetch the database list available in the storage account.

    Args:
        client (_type_): _description_
    """
    try:
        logging.info('Databases:-')
        databases = list(client.list_databases())
        if not databases:
            logging.info('No Database found')
            return
        for database in databases:
            logging.info(database['id'])
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc()) 

def insert_account_record(client, container, data):
    """function facilitates the record insertion in the account container.

    Args:
        client (_type_): _description_
        name (_type_): _description_
        subscription (_type_): _description_
    """
    new_item = create_account_record(data)
    try:
        database = client.get_database_client({"id":container}) 
        container = database.get_container_client({"id":"Items"})
        existing_item = container.read_item(item=new_item['id'], partition_key=new_item['id'])
        return False
    except exceptions.CosmosResourceNotFoundError:
        response = container.upsert_item(new_item)
        if not response:
            logging.info("account insertion to database failed")
            return
        logging.info(response)
        return True

def create_account_record(data):
    if 'tag_conditions' in data:
        tag_conditions = data['tag_conditions']
        if 'key' in data['tag_conditions']:
            tag_key = data['tag_conditions']['key']
        else:
            tag_key = None  
        if 'value' in data['tag_conditions']:
            tag_value = data['tag_conditions']['value']
        else:
            tag_value = None
    else:
        tag_conditions ={}
        tag_key = None
        tag_value = None
    if tag_key is not None and tag_value is not None:
        id = data['subscription_id']+"-"+base64.b64encode((tag_key + tag_value).encode('utf-8')).decode('utf-8')
    else:
        id = data['subscription_id']
    parameters = {
    "id": id,
    "subscription_id": data['subscription_id'],
    "alarm_configuration": data['alarm_configuration'],
    "app_name": data['app_name'],
    "region": 'global',
    'is_deleted': False,
    "audit": [
        {
            "id": data['subscription_id'],
            "created_on": str(datetime.now().timestamp())[:10],
            "existing_alarm": True if data['existing_alarm'] =="true" else False,
            "user": data['user'],
            "alarms": [
            ],
            "priority": "p1",
            "action": "post-alarms/sync",
            "updated_on": str(datetime.now().timestamp())[:10]
        }
    ],
    "delegates": {
        "dl": [],
        "selected_users": [
            {
                "emailAddress": data['user'],
                "fullName": data['user'],
                "userName": data['user']
            }
        ]
    },
    "environment": data.get('environment'),
    "existing_alarm": True if data['existing_alarm'] =="true" else False,
    "service_status": True,
    "status": "in-progress",
    "auto_alarm": True if data['auto_alarm'] =="true" else False,
    "created_by": data['user'],
    "created_on": str(datetime.now().timestamp())[:10],
    "tag_conditions": tag_conditions,
    "updated_on": str(datetime.now().timestamp())[:10]
    }
    return parameters

def delete_record(subscription, client, container, req):
    """function to facilitates the record deletion in the provided container.

    Args:
        client (_type_): _description_
        name (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        response = call_app_alert(subscription,type="delete",data=req)

        if not response:
            logging.info("request didnt processed")
            return 200, "delete record failed."
        else:
            logging.info("response recieved from the database deletion")
            logging.info(response)
            return 200, "success"
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc())

def delete_account(subscription, client, container, req):
    """function to facilitates the account offboading.

    Args:
        client (_type_): _description_
        name (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        query = f"""
            SELECT * FROM c WHERE c.subscription_id = '{subscription}' AND c.is_deleted = false
            """
        database = client.get_database_client({"id":"alarms"})
        container = database.get_container_client({"id":"Items"})
        a_database = client.get_database_client({"id":"account"})
        a_container = a_database.get_container_client({"id":"Items"})

        items = list(container.query_items(query=query, enable_cross_partition_query=True))
        id_list = [{"id": item["alarm_name"]} for item in items]
        req['alarms'] = id_list
        logging.info("the alarms list created for delete account")
        call_app_alert(subscription,type="delete",data=req)
        account_record = a_container.read_item(item=subscription, partition_key=subscription)
        account_record['is_deleted'] = True
        a_container.upsert_item(account_record)
        return 200, "account offboarding completed!."
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc())

def create_event_grid(client):
    """creates event grid system topic in provided subscription as a part of onboarding.

    Args:
        client (_type_): _description_
    """
    try:
        response = client.system_topics.begin_create_or_update(
        resource_group_name=GROUP_NAME,
        system_topic_name=TOPIC_NAME,
        system_topic_info={
                "location": "Global",
                "properties": {
                    "source": "/subscriptions/e4148e6d-1440-4160-9529-ac19265cbf69",
                    "topicType": "Microsoft.Resources.Subscriptions",
                    "target": "",
                },
                "tags": {"tag1": "value1", "tag2": "value2"},
            },
        ).result()
        print(response)
        logging.info('\nCreated event grid topic successfully...')
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc())

def update_alarms(client, req):
    status_code = 401
    status = 'failed'
    destination = ''
    database = client.get_database_client({"id":"alarms"})
    container = database.get_container_client({"id":"Items"}) 
    for alarm in req["alarms"]:
        logging.info("inside update alarms loop.")
        query =f"""
            SELECT * FROM c WHERE c.alarm_name = '{alarm}'
            """
        existing_data = list(container.query_items(query, enable_cross_partition_query=True))[0]
        logging.info("inside update alarm option")
        logging.info(existing_data)
        if existing_data:
            try:
            #     item_to_replace['updated_on'] = str(datetime.now().timestamp())[:10]
            #     #... [rest of the update and remove expressions logic]
            #     update_attr_value = build_update_attr_value(req,item_to_replace)
            #     for key, value in update_attr_value.items():
            #         # Removing the ':' prefix from the keys for Cosmos DB compatibility
            #         cosmos_key = key[1:]
            #         item_to_replace[cosmos_key] = value
            #     container.replace_item(item=item_to_replace, body=item_to_replace)
                existing_data['updated_on'] = str(datetime.now().timestamp())[:10]

                if 'priority' in req and req['priority']:
                    existing_data['priority'] = req['priority']
                else:
                    if 'priority' in existing_data:
                        del existing_data['priority']

                if 'alarm_threshold' in req and req['alarm_threshold']:
                    existing_data['alarm_threshold'] = req['alarm_threshold']

                if 'alarm_description' in req and req['alarm_description']:
                    existing_data['alarm_description'] = req['alarm_description']

                if 'configuration_item' in req and req['configuration_item']:
                    existing_data['configuration_item'] = req['configuration_item']
                else:
                    if 'configuration_item' in existing_data:
                        del existing_data['configuration_item']
                if req.get('sys_id'):
                    existing_data['sys_id'] = req.get('sys_id')

                if 'slack_channel' in req and req['slack_channel']:
                    existing_data['slack_channel'] = req['slack_channel']
                else:
                    if 'slack_channel' in existing_data:
                        del existing_data['slack_channel']

                if 'pagerduty' in req and req['pagerduty']:
                    existing_data['pagerduty'] = req['pagerduty']
                else:
                    if 'pagerduty' in existing_data:
                        del existing_data['pagerduty']

                if req.get('email'):
                    existing_data['email'] = req.get('email')
                
                if req.get('serviceId'):
                    existing_data['serviceId'] = req.get('serviceId')
                    destination += ',dora_explorer' if destination else 'dora_explorer'
                else:
                    if 'serviceId' in existing_data:
                        del existing_data['serviceId']

                if 'runbook_url' in req and req['runbook_url']:
                    existing_data['runbook_url'] = req['runbook_url']
                else:
                    if 'runbook_url' in existing_data:
                        del existing_data['runbook_url']

                if req.get('alert_threshold'):
                    existing_data['alert_threshold'] = req.get('alert_threshold')

                if req.get('auto_remediation'):
                    existing_data['auto_remediation'] = req.get('auto_remediation')
                    destination += ',autobots' if destination else 'autobots'

                if 'destination' in req and req['destination']:
                    existing_data['destination'] = req['destination']
                else:
                    if 'destination' in existing_data:
                        del existing_data['destination']
                if 'audit' in existing_data and existing_data['audit']:
                    del existing_data['audit']
                    existing_data['audit'] = [json.dumps(existing_data)]

                logging.info("the data after updation is ........")
                logging.info(existing_data)

                container.upsert_item(body=existing_data)
                # Assuming you still want to invoke an Azure Function for additional processing
                if req.get('update_alarm'):
                    call_app_alert(req['subscription_id'],type="update-alarm",data=req)
                status_code = 200
                status = 'success'
                return status_code, status
            except Exception:
                    post_slack(
                    "secret", 'Process Failed with the error', traceback.format_exc())
        else:
            return 200, "alert upadte failed with db error."

def update_alarms_for_resync(client, req):
    status_code = 401
    status = 'failed'

    for alarm in req["alarms"]:
        logging.info("inside update alarms loop.")
        database = client.get_database_client({"id":"alarms"})
        container = database.get_container_client({"id":"Items"}) 
        try:
            #... [rest of the update and remove expressions logic]
            new_item = req
            new_item['updated_on'] = str(datetime.now().timestamp())[:10]
            new_item['id'] = alarm
            new_item['alarm_name'] = alarm
            new_item['is_deleted'] = False
            # Replace the item
            del new_item['alarms']
            container.upsert_item(new_item)
            # Assuming you still want to invoke an Azure Function for additional processing
            print('Info: Alarms updated in Azure Cosmos DB')
            status = 'success'
            return status
        except Exception:
                post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def build_update_attr_value(data,item_to_replace):
    """creating attributes for update method

    Args:
        data (_type_): _description_

    Returns:
        _type_: _description_
    """
    update_attr_value = {
        # for later use
        ':alarm_threshold': data.get('alarm_threshold', 0),
        ':configuration_item': data.get('configuration_item', ''),
        ':alarm_description': data.get('alarm_description',''),
        ':pagerduty': data.get('pagerduty',''),
        ':serviceId': data.get('serviceId',''),
        ':runbook_url': data.get('runbook_url',''),
        ':subscription_id': data.get('subscription_id'),
        ':priority' : data.get('priority',1),
        ':empty_audit': [],
        ':email': data.get('email',''),
        ':slack_channel': data.get('slack_channel',''),
        ':audit': [json.dumps(data)]  # removed cls=DecimalEncoder for simplicity, reintroduce if needed
    }
    # ... additional conditions can be added here to extend the dictionary
    return update_attr_value

def create_event_grid_subscption(client):
    """creates subscription for the system topic which sent data accross event grid. 

    Args:
        client (_type_): _description_
    """
    try:
        response  = client.system_topic_event_subscriptions.begin_create_or_update (
        resource_group_name=GROUP_NAME,
        system_topic_name=TOPIC_NAME,
        event_subscription_name= "cloudmonitoring-event-subscription",
        event_subscription_info={
        "properties": {
            "destination": {
                "endpointType": "WebHook",
                "properties": {
                    "endpointUrl": "https://cm-app-default-dev.westus2-1.eventgrid.azure.net/api/events",
                        "deliveryAttributeMappings": [
                        {
                            "name": "aeg-sas-key",
                            "type": "Static",
                            "properties": {
                                "value": "uUUHsKufmQ/ACUPc5zMUYmUZ/YtS7Rzmb66U+6+BV+M=",
                                "isSecret": True
                            }
                        }
                    ]
                }
            },
            "filter": {
                "includedEventTypes": [
                    "Microsoft.Resources.ResourceWriteSuccess",
                    "Microsoft.Resources.ResourceWriteFailure",
                    "Microsoft.Resources.ResourceWriteCancel",
                    "Microsoft.Resources.ResourceDeleteSuccess",
                    "Microsoft.Resources.ResourceDeleteFailure",
                    "Microsoft.Resources.ResourceDeleteCancel",
                    "Microsoft.Resources.ResourceActionSuccess",
                    "Microsoft.Resources.ResourceActionFailure",
                    "Microsoft.Resources.ResourceActionCancel"
                ],
                "advancedFilters": [],
                "enableAdvancedFilteringOnArrays": True
            },
            "labels": [], 
            "eventDeliverySchema": "CloudEventSchemaV1_0"
        },
                "tags": {"tag1": "value1", "tag2": "value2"}

        }
            
        ).result()
        print(response)
        logging.info('\nCreated event grid sunscription successfully...')
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def records_filter(db, item, client):
    """funtion to fetch records details from container based on the a specified key.
    Args:
        container (_type_): _description_
        item (_type_): key value pair which consist of the query parameters.
        client (_type_): _description_
    Returns:
        _type_: _description_
    """
    try:
        database = client.get_database_client({"id":db})
        container = database.get_container_client({"id":"Items"})
        key_name = item['key']
        key_value = item['value']

        # Define the SQL query to select items with the specified key-value pair
        query = f"SELECT * FROM c WHERE c.{key_name} = '{key_value}'"
        if db == "alarms":
            query = query+" AND c.is_deleted = false"
        logging.info("query created.")
        logging.info(query)

        response = list(container.query_items(query, enable_cross_partition_query=True))
        logging.info(response)
        if not response:
            logging.info("request didnt processed")
            return
        else:
            logging.info("response recieved from the database filtering")
            for item in response:
                logging.info("the items recieved..")
                logging.info(item)
            return response
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def call_app_alert(subscription_id, action=None,type=None, data=None):
    """calls external function : cm-app-alert with the parameters.

    Args:
        path (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """
    try:
        headersAuth = {
        'Authorization': app_alert_function_key}
        data['action']=action
        data['type']=type
        data["subscription_id"]=subscription_id

        response = requests.post(url=app_alert_no_token,json=data, timeout=2)
        logging.info("app alert called..")
        logging.info(response)
        return response
    except requests.exceptions.ReadTimeout:
        pass
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def list_resource_group(resource_client):
    """list the resource groups available in the subacription.

    Args:
        resource_client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        resource_groups = resource_client.resource_groups.list()
        logging.info("the resource group list service")
        # Print the name of each resource group
        if len(list(resource_groups))>0:   
            return True
        else:
            return response  
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def get_configuration(client,req):
    """handle configuration

    Args:
        client (_type_): _description_
        req (_type_): _description_
    """ 
    database = client.get_database_client({"id":"configuration"})
    container = database.get_container_client({"id":"Items"})
    body = req.get_json() if req.get_body() else None
    if body and 'partition_key' in body:
            id = body['partition_key']
    else:
            parsed_url = urlparse(req.url)
            query_params = parse_qs(parsed_url.query)
            logging.info(query_params)
            id = query_params.get('/configuration?id')
            logging.info(id)
            id = id[0] if id else None
    logging.info(id)
    if id == None:
        logging.info("inside id is none")
        query = "SELECT c.id, c.name FROM c"
        response = list(container.query_items(query, enable_cross_partition_query=True))
        logging.info(response)
    else:
        query = f"SELECT * FROM c WHERE c.id = '{id}'"
        logging.info(query)
        response = list(container.query_items(query, enable_cross_partition_query=True))[0]
        logging.info(response)
    return response
    
def get_record(client, database_id, data):
    """function to fetch a specific record from a database.

    Args:
        container (_type_): _description_
        item (_type_): _description_
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        database = client.get_database_client({"id":database_id})
        container = database.get_container_client({"id":"Items"})

        body = data.get_json() if data.get_body() else None
        if body and 'partition_key' in body:
            id = body['partition_key']
        else:
            parsed_url = urlparse(data.url)
            id = parsed_url.query.split('id=')[1] if parsed_url.query else None
            logging.info("id passed...")
            logging.info(id)
        if id == "all":
            query = "SELECT * FROM c WHERE  c.is_deleted = false"
            response = list(container.query_items(query, enable_cross_partition_query=True))
        elif database_id == "account":
            query = f"SELECT * FROM c WHERE  c.is_deleted = false AND c.id ='{id}'"
            response = list(container.query_items(query, enable_cross_partition_query=True))[0]
        else:   
            response = container.read_item(item=id, partition_key=id)
        if not response:
            logging.info("request didnt processed")
            return 200, "No response returned from database!"
        else:
            return response
    except IndexError:
        return 200, "No account found in the database"
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())
        return 500, traceback.format_exc()

def get_alerts(client, database, req):
    """get alrets filtered based on filter condition

    Args:
        client (_type_): _description_
        database (_type_): _description_
        req (_type_): _description_

    Returns:
        _type_: _description_
    """
    parsed_url = urlparse(req.url)
    id = parsed_url.query.split('id=')[1] if parsed_url.query else None
    query_data ={
        "key":"subscription_id",
        "value":id
    }
    logging.info(query_data)
    try:
        response = records_filter(database, query_data, client)
        if not response:
            logging.info("request didnt processed")
            return "No response returned from database!"
        else:
            logging.info(response)
            return response
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def list_all_alerts(client):
    """listing all alerts

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    alert_list = []
    try:
        alerts = client.metric_alerts.list_by_subscription()
        if not alerts:
            return 200, "No alerts found"
        for alert in alerts:
            # keeping this in comment if required later
            # data={}
            # data['id'] = alert.name if alert.name else 'N/A'
            # data['name']=alert.id if alert.id else 'N/A'
            # data['type']= alert.type if alert.type else "N/A"
            # data['priority']=alert.severity if alert.severity else "N/A"
            # data['duplicate'] = ''
            alert_list.append(alert.name)

        logging.info(alert_list)
        return alert_list
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def threshold_configuration(client, req):
    """ get threshold of the configuration..

    Args:
        client (_type_): _description_
        req (_type_): _description_

    Returns:
        _type_: _description_
    """
    logging.info("threshold configuration..")
    body = req.get_json() if req.get_body() else None
    database = client.get_database_client({"id":"configuration"})
    container = database.get_container_client({"id":"Items"})
    if body and 'partition_key' in body:
            id = body['partition_key']
    else:
            parsed_url = urlparse(req.url)
            id = parsed_url.query.split('id=')[1] if parsed_url.query else None
            logging.info("id passed...")
            logging.info(id)
    query = f"SELECT * FROM c WHERE c.id = '{id}'"
    logging.info(query)
    data = list(container.query_items(query, enable_cross_partition_query=True))[0]
    logging.info("the data obtained from database")
    logging.info(data)
    try:
        response = {}
        for resource in data["configuration"]["M"]:
            if resource in allowed_resources:
                response[resource] = {}
                logging.info(data["configuration"]["M"][resource])
                for definition in data["configuration"]["M"][resource]['defination']:
                    metric_name = definition["metricName"]
                    alarm_version = definition["alarm_version"]
                    threshold = definition["threshold"]
                    response[resource][metric_name]={}
                    response[resource][metric_name][alarm_version] = threshold
            logging.info(response)
        return response
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())
        
def call_app_list_alarms(subscription_id, conf=None, path=None,type=None,tag_key=None,tag_value=None):
    """calls external function : cm-app-list-services

    Args:
        path (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """

    logging.info('in cm-app-list-services call:-')
    try:
        headersAuth = {
        'Authorization': app_list_function_key} # will remove this later. once managed identity is implemented.
        requests.post(url=app_list_services,json={"path":path,"type":type,"alarm_configuration":conf, "subscription_id":subscription_id,"tag_conditions":{"key":tag_key,"value":tag_value}}, timeout=2)
    except requests.exceptions.ReadTimeout:
        pass
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def schedule_async_function(loop, data):
    asyncio.ensure_future(call_app_list_alarms(subscription_id=data["subscription_id"]), loop=loop)

class DecimalEncoder(json.JSONEncoder):
    """Class for converting ItemPaged object to json.

    Args:
        json (_type_): _description_
    """
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.timestamp()
        return obj.__dict__ 

def post_slack(secret, msg, e):
    """function pushes errors to slack as a part of user notification.

    Args:
        secret (_type_): _description_
        msg (_type_): _description_
        e (_type_): _description_
    """
    # print('Error:' if e else 'Info:', msg, e)
    # url = secret.get('slack_url')
    # headers = {
    #     'x-api-key':  secret.get('slack_key'),
    #     'content-type': 'application/json'
    # }

    # pld = {
    #     'status': 'failed' if e else 'ok',
    #     'impacted_area': f'{os.environ.get("FUNCTION")} || {msg}',
    #     'description': str(e),
    #     'slack': secret.get('slack_channel'),
    #     'dpe_division': 'des'
    # }
    # r = requests.post(url, data=json.dumps(pld), headers=headers)
    # print('Info: Error posted to slack', r.status_code)

    logging.info("inside post slack")
    logging.info(secret)
    logging.info(msg)
    logging.info(e)
