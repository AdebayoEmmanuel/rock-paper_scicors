import random
import os
import sys
import json
from datetime import datetime
import logging
import requests
import traceback
from itertools import tee
import azure.functions as func
from azure.identity import ClientSecretCredential, DefaultAzureCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.storage.blob import BlobServiceClient
from azure.cosmos import CosmosClient, ConsistencyLevel
from azure.keyvault.secrets import SecretClient


# Key vault name
KEYVAULT_NAME = "cm-app-keyvault-dev"

def get_keyvault_secret(secret_name: str) -> str:
    """get secrets from key vaults

    Args:
        secret_name (str): _description_

    Returns:
        str: _description_
    """
    try: 
        # Use Managed Identity or set credentials as needed
        m_credential =  DefaultAzureCredential(managed_identity_client_id="2017d6f9-0450-48ef-bb90-70e5ecbed375")
        logging.info("the default credentials...")
        logging.info(str(m_credential))
        secret_client = SecretClient(vault_url=f"https://{KEYVAULT_NAME}.vault.azure.net", credential=m_credential)
        secret = secret_client.get_secret(secret_name).value
        return secret
    except Exception as e:
        post_slack("secret", 'Error getting secret from Key Vault', traceback.format_exc())
        return ""

logging.basicConfig(level=logging.DEBUG)
current_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(current_dir, "../dependencies"))
logging.info("current directory")
logging.info(current_dir)


LOCATION = 'westus2'
GROUP_NAME = 'cloud-monitoring'
TOPIC_NAME = "cloudmonitoringtest1"
subscription_id = get_keyvault_secret("SubscriptionId")
ENDPOINT_URL = "replace with your Azure function-URL that support validation"
HOST = 'https://cm-app-global-dev.documents.azure.com:443/'
MASTER_KEY = get_keyvault_secret("MasterKey")
client_id=get_keyvault_secret("ClientId")
client_secret = get_keyvault_secret("clientSecret")
tenant_id=get_keyvault_secret("TenantId")
event_grid_access_key = get_keyvault_secret("EventGridAccessKey")
event_grid_topic_endpoint = "https://cm-app-testing-grid-topic.westus2-1.eventgrid.azure.net/api/events"
blob_account = "https://cmappexistingstoragedev.blob.core.windows.net"
blob_container = "cmappstoragecontainerexistingdev"
blob_key = get_keyvault_secret("BlobKey")
put_alarm_no_token = "https://cm-app-existing-resource-dev.azurewebsites.net/api/cm-app-put-alarm"
put_alarm_function_key = get_keyvault_secret("PutAlarm")
app_alert_url  =   "https://cm-app-flow-validation.azurewebsites.net/admin/functions/cm-app-alarms"
app_alert_function_key = get_keyvault_secret("AppalertFunctionKey")
credential = ClientSecretCredential(
    client_id=client_id,
    client_secret=client_secret,
    tenant_id=tenant_id
)
    
def main(req: func.HttpRequest) -> func.HttpResponse:
    """main function to be called initially

    Args:
        req (_type_): _description_

    Returns:
        _type_: _description_
    """

    logging.info('Python trigger processing an event')
    run(req.get_json())
    logging.info('Python trigger processed an event')
    return func.HttpResponse('ok', status_code=200)

def run(req):
    logging.info("Info: function called with the input..")
    logging.info(req)
    blob_service_client = BlobServiceClient(
        account_url=blob_account,
        credential=blob_key
    )
    tags = req.get('tag_conditions', {})
    subscription_id = req.get('subscription_id', {})
    configuration = req.get('alarm_configuration', {})
    logging.info(tags)
    filters = []
    if tags:
            filters.append({
                'Name': 'tag:' + tags['key'],
                'Values': [tags['value']]
            })

    logging.info(tags)
    web_mgmt_client = ResourceManagementClient(credential, subscription_id)
    cosmos_client = CosmosClient(HOST, {'masterKey': MASTER_KEY}, ConsistencyLevel.Eventual )

    blob_name = list_services(web_mgmt_client, tags, blob_service_client, blob_container)

    
    # if response =="200":
    #     call_put_alarm(blob_name)
    logging.info("the blob name generated...")
    logging.info(blob_name)

    call_put_alarm("coloud_monitoring-test0.03336925727368989",subscription_id,tags,configuration) # test code for an available blob.
    # call_put_alarm(blob_name,subscription_id,tags)
    # update_account(cosmos_client,req)

def list_alarms(client):
    """function to list alarms in the subscription

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        alerts = client.metric_alerts.list_by_subscription()    
        logging.info('Info: alerts found..:-')
        if not alerts:
            logging.info('No alerts found')
            return
        for alert in alerts:
            logging.info(alert)
        return alerts
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def list_databases(client):
    """function to list the available databasein the given subsctiption.

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
 
        databases = list(client.list_databases())
        if not databases:
            logging.info('No Database found')
            return
        logging.info('Info: Databases found :-')
        for database in databases:
            logging.info(database['id'])
        return database
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def list_services(client, tag, blob_service_client, blob_container):
    """listing all the available services in a subscription.

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """

    Function_apps =[]
    DatabaseAccounts =[]
    StorageAccounts =[]
    Metricalerts =[]
    VirtualMachines = []
    VirtualMachineScaleSets =[]
    ComputingGallery=[]

    try:
        logging.info("inside try.")
        tag_key = tag['key']
        tag_value = tag['value']
        filter_criteria = f"tagName eq '{tag_key}' and tagValue eq '{tag_value}'"

        logging.info("the filter condition")
        logging.info(filter_criteria)

        resource_list = client.resources.list(filter=f"tagName eq '{tag_key}' and tagValue eq '{tag_value}'")
        for resource in list(resource_list):
            logging.info("the resuorce in action ")
            logging.info(resource.id)
            if (resource.type == "Microsoft.Web/sites" ) or (resource.kind == "functionapp") or (resource.kind == "linux" ):
                Function_apps.append(resource)
            elif (resource.type == "Microsoft.Storage/storageAccounts" ):
                StorageAccounts.append(resource)
            elif (resource.type == "Microsoft.DocumentDb/databaseAccounts" ):
                DatabaseAccounts.append(resource)
            elif(resource.type == "Microsoft.Insights/metricalerts" ):
                Metricalerts.append(resource)
            elif (resource.type == "Microsoft.Compute/virtualMachines" ):
                VirtualMachines.append(resource)
            elif (resource.type == "Microsoft.Compute/virtualMachineScaleSets" ):
                VirtualMachineScaleSets.append(resource)
            elif (resource.type == "Microsoft.Gallery/applications" ):
                ComputingGallery.append(resource)

        response = json.dumps({
            'FunctionApp': Function_apps,
            'DatabaseAccounts': DatabaseAccounts,
            'StorageAccounts': StorageAccounts,
            'MetricAlerts': Metricalerts,
            'VirtualMachine': VirtualMachines,
            'VirtualMachineScaleSets': VirtualMachineScaleSets,
            'ComputingGallery': ComputingGallery

        }, cls=DecimalEncoder)
            
        logging.info("the response from the list services..")
        logging.info(response)
        blob_response, blob_name = insert_to_blobstorage(blob_service_client, blob_container, response)
        return blob_name
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def insert_to_blobstorage(blob_client, blob_container, data):
    """function to insert azure item paged data to azure blob storage.

    Args:
        blob_client (_type_): _description_
        blob_container (_type_): _description_
        data (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        container = blob_client.get_container_client(blob_container)
        logging.info(container)
        logging.info(data)
        blob_name = "coloud_monitoring-test" + str(random.random()) #randon number is added as suffix for testing.
        response = container.upload_blob(name=blob_name,data=json.dumps(data, cls=DecimalEncoder))
        logging.info("the blob response")
        logging.info(response)
        return (response, blob_name)
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def call_put_alarm(blob,subscription_id,tags,configuration):
    """function to call cm-app-alert function with required parameters.

    Args:
        vm_list (_type_): _description_
    """
    logging.info('in cm-app-put-alarm call:-')
    try:
        headersAuth = {
        'Authorization': put_alarm_function_key} # will remove once managed identity is implemented..
        response = requests.post(url=put_alarm_no_token,json={"blob":blob,'configuration':configuration,'subscription_id':subscription_id,'tags':tags})
        logging.info("app put alarm called...")
        logging.info(response)
        return response
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def call_app_alert(subscription_id, path=None,type=None, data=None):
    """calls external function : cm-app-alert with the parameters.

    Args:
        path (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """

    logging.info('calling cm-app-alert function:-')
    try:
        headersAuth = {
        'Authorization': app_alert_function_key}
        data['path']=path
        data['type']=type
        data["subscription_id"]=subscription_id

        response = requests.post(url=app_alert_url,json=data)
        logging.info("app alert called..")
        logging.info(response)
        return response
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def update_account(client,req):
    """function to update a existing record on the account container

    Args:
        client (_type_): _description_
        item (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        logging.info("inside update account method..1")
        query_data ={
        "partition_key":req["id"],
        "item":req['id']
    }
        record = get_record(client,"account",query_data)
        database = client.get_database_client({"id":"account"}) 
        record['status'] = "alert_creation_in_progress"
        container = database.get_container_client({"id":"Items"})
        response = container.upsert_item(record)

        if not response:
            logging.info("request didnt processed")
            return 
        else:
            logging.info("response recieved from the database insertion")
            for item in response:
                logging.info("the current item")
                logging.info(item)
            return response
    except Exception:
            post_slack(
            "secret", 'Process Failed with the error', traceback.format_exc())

def get_record(client,database_id, data):
    """function to fetch a specific configuration from configuration container.

    Args:
        container (_type_): _description_
        item (_type_): _description_
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    logging.info("inside the get function...")
    try:
        database = client.get_database_client({"id":database_id})
        container = database.get_container_client({"id":"Items"})
        response = container.read_item(item=data["item"], partition_key=data["partition_key"])
        logging.info(response)
        if not response:
            logging.info("request didnt processed")
            return
        else:
            # create_alert_virtual_machine(monitor_client, response['configuration']['M']['VirtualMachine']['defination'])
            return response
    except Exception:
            post_slack(
            "secret", 'Failed toread item the error', traceback.format_exc())

def generate_filter_parameters(tk, tv):

    return [
            {
                'resource_type': 'Microsoft.Web/sites',
                'tagname': tk,
                'tagvalue': tv
            },
            {
                'resource_type': 'Microsoft.Storage/storageAccounts',
                'tagname': tk,
                'tagvalue': tv
            },
            {
                'resource_type': 'Microsoft.DocumentDb/databaseAccounts',
                'tagname': tk,
                'tagvalue': tv
            },
            {
                'resource_type': 'Microsoft.Insights/metricalerts',
                'tagname': tk,
                'tagvalue': tv
            },
            {
                'resource_type': 'Microsoft.Compute/virtualMachines',
                'tagname': tk,
                'tagvalue': tv
            },
            {
                'resource_type': 'Microsoft.Compute/virtualMachineScaleSets',
                'tagname': tk,
                'tagvalue': tv
            },
            {
                'resource_type': 'Microsoft.Gallery/applications',
                'tagname': tk,
                'tagvalue': tv
            }
    ]

def post_slack(secret, msg, e):
    """function pushes errors to slack as a part of user notification.

    Args:
        secret (_type_): _description_
        msg (_type_): _description_
        e (_type_): _description_
    """
    # print('Error:' if e else 'Info:', msg, e)
    # url = secret.get('slack_url')
    # headers = {
    #     'x-api-key':  secret.get('slack_key'),
    #     'content-type': 'application/json'
    # }

    # pld = {
    #     'status': 'failed' if e else 'ok',
    #     'impacted_area': f'{os.environ.get("FUNCTION")} || {msg}',
    #     'description': str(e),
    #     'slack': secret.get('slack_channel'),
    #     'dpe_division': 'des'
    # }
    # r = requests.post(url, data=json.dumps(pld), headers=headers)
    # print('Info: Error posted to slack', r.status_code)
    print("the error raised. ",e)

class DecimalEncoder(json.JSONEncoder):
    """Class for converting ItemPaged object to json.

    Args:
        json (_type_): _description_
    """
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.timestamp()
        return obj.__dict__ 