import random
import datetime
import os
import sys
import json
import traceback
import logging
import requests
logging.basicConfig(level=logging.DEBUG)
import uuid
import azure.functions as func
from azure.identity import ClientSecretCredential, DefaultAzureCredential
from azure.mgmt.monitor import MonitorManagementClient
from azure.cosmos import CosmosClient, ConsistencyLevel
from azure.storage.blob import BlobServiceClient
from azure.keyvault.secrets import SecretClient

# Key vault name
KEYVAULT_NAME = "cm-app-keyvault-dev"

def get_keyvault_secret(secret_name: str) -> str:
    """get secrets from key vaults

    Args:
        secret_name (str): _description_

    Returns:
        str: _description_
    """
    try: 
        # Use Managed Identity or set credentials as needed
        m_credential =  DefaultAzureCredential(managed_identity_client_id="2017d6f9-0450-48ef-bb90-70e5ecbed375")
        logging.info("the default credentials...")
        logging.info(str(m_credential))
        secret_client = SecretClient(vault_url=f"https://{KEYVAULT_NAME}.vault.azure.net", credential=m_credential)
        secret = secret_client.get_secret(secret_name).value
        return secret
    except Exception as e:
        post_slack("secret", 'Error getting secret from Key Vault', traceback.format_exc())
        return ""

current_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(current_dir, "../dependencies"))

print("current directory", current_dir)
LOCATION = 'westus2'
GROUP_NAME = 'cloud-monitoring'
TOPIC_NAME = "cloudmonitoringtest1"
subscription_id = get_keyvault_secret("SubscriptionId")
ENDPOINT_URL = "replace with your Azure function-URL that support validation"
HOST = 'https://cm-app-global-dev.documents.azure.com:443/'
MASTER_KEY = get_keyvault_secret("MasterKey")
client_id=get_keyvault_secret("ClientId")
client_secret = get_keyvault_secret("clientSecret")
tenant_id=get_keyvault_secret("TenantId")
event_grid_access_key = get_keyvault_secret("EventGridAccessKey")
event_grid_topic_endpoint = "https://cm-app-testing-grid-topic.westus2-1.eventgrid.azure.net/api/events"
app_list_services = "https://cm-app-flow-validation.azurewebsites.net/admin/functions/cm-app-list-services"
app_list_function_key = get_keyvault_secret("AppListServices")
blob_account = "https://cloudmonitoringb623.blob.core.windows.net"
blob_container = "cloudmonitoring-resource-identifier"
blob_key = get_keyvault_secret("BlobKey")
put_alarm_url="https://cm-app-flow-validation.azurewebsites.net/admin/functions/cm-app-put-alarm?code=V76pJ_L9Nq2TggLbANMPY9St-IToTG5mO6yS-io-chA3AzFud8DoBQ=="
put_alarm_no_token = "https://cm-app-flow-validation.azurewebsites.net/admin/functions/cm-app-put-alarm"
put_alarm_function_key = get_keyvault_secret("PutAlarm")
credential = ClientSecretCredential(
    client_id=client_id,
    client_secret=client_secret,
    tenant_id=tenant_id
)
monitor_client = MonitorManagementClient(credential, subscription_id)
cosmos_client = CosmosClient(HOST, {'masterKey': MASTER_KEY}, ConsistencyLevel.Eventual )


def main(req):
    """main function to be called initially

    Args:
        req (_type_): _description_

    Returns:
        _type_: _description_
    """

    logging.info('Python trigger processing an event')
    status_code,status = run(req.get_json())
    # delete_alert(monitor_client, cosmos_client, req.get_json())

    logging.info('Python trigger processed an event')
    return func.HttpResponse(status_code=status_code, body=json.dumps({'status':status }))

def run(req):
    if req['type'] == 'create':

        alarm_list = create_alert(monitor_client, req)
        insert_record(cosmos_client,"alarms", alarm_list)
        return 200, "sucess"

    if req['type'] =='list':
        return 200, list_alarms(monitor_client)

    if req['type'] == 'update':
        return 200, update_alert_db(cosmos_client, req)
    
    if req['type'] == "update-alarm":
        logging.info("inside update alarm function..")
        return 200, update_alert(monitor_client,cosmos_client, GROUP_NAME, req)
    
    if req['type'] == "delete":
        return 200, delete_alert(monitor_client, cosmos_client, req)

    if req['type'] == "update-configuration":
        return 200, update_alarm_configuration(cosmos_client, monitor_client, req)

    if req['type'] =="resync-list":
        client = MonitorManagementClient(credential, req['subscription_id'])
        return 200, resync_alarms(client)

    logging.info('\nmain function called...')

def list_alarms(client):
    """function to list alarms in the subscription

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    alert_list = []
    try:
        alerts = client.metric_alerts.list_by_subscription()
        if not alerts:
            logging.info('No alerts found')
            return
        for alert in alerts:
            data={}
            data['id'] = alert.id if alert.id else 'N/A'
            data['name']=alert.name if alert.name else 'N/A'
            data['type']= alert.type if alert.type else "N/A"
            data['priority']=alert.severity if alert.severity else "N/A"
            data['duplicate'] = ''
            alert_list.append(data)

        logging.info(alert_list)
        return alert_list
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def resync_alarms(client):
    """resync alarms

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    alert_list = []
    try:
        alerts = client.metric_alerts.list_by_subscription()
        if not alerts:
            return 200, "No alerts found"
        for alert in alerts:
            data={}
            data['id'] = alert.id if alert.id else 'N/A'
            data['name']=alert.name if alert.name else 'N/A'
            data['type']= alert.type if alert.type else "N/A"
            data['priority']=alert.severity if alert.severity else "N/A"
            data['duplicate'] = ''
            alert_list.append(data)

        logging.info(alert_list)
        return alert_list
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def list_databases(client):
    """function to list the available databasein the given subsctiption.

    Args:
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        logging.info("Info: Database.")
        databases = list(client.list_databases())
        if not databases:
            logging.info('No Database found')
            return
        for database in databases:
            logging.info(database['id'])
        return databases
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def insert_record(client,databse_id, data):
    """function to insert recoed in the provided contaier.

    Args:
        client (_type_): _description_
        name (_type_): _description_
    """
    try:
        for item in data:
            new_item = {
                "id":"metric_alert"+item['name'].split("/")[-1],
                "alarm_name": item['name'],
                "resource_id": str(item['id']),
                "type": 'existing' if item['duplicate'] else 're-sync',
                "priority": item['priority'],
                "user": "",
                "updated_on": str(datetime.now().timestamp())[:10]
            }
            logging.info(new_item)
            database = client.get_database_client({"id":databse_id})
            container = database.get_container_client({"id":"Items"})
            response = container.create_item(new_item)
        if not response:
            logging.info("request didnt processed")
            return
        else:
            logging.info("response recieved from the database insertion")
            logging.info(response)
            return
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def delete_record(client, database, record):
    """function to delete record from the provided container.

    Args:
        client (_type_): _description_
        name (_type_): _description_
    """
    try:
        database = client.get_database_client({"id":database})
        container = database.get_container_client({"id":"Items"})
        response = container.delete_item(item=record['item'],partition_key=record['partition_key'])

        if not response:
            logging.info("request didnt processed")
            return
        else:
            logging.info("response recieved from the database deletion")
            logging.info(response)
            return
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def update_record(client, data_base_id,new_item ):
    """function to update the record in the provided container.

    Args:
        client (_type_): _description_
        name (_type_): _description_
    """
    try:
        logging.info("inside the update record method..")
        database = client.get_database_client({"id":data_base_id})
        container = database.get_container_client({"id":"Items"})
        logging.info("inside update record mehthod..")
        logging.info(new_item)
        response = container.upsert_item(new_item)

        if not response:
            logging.info("request didnt processed")
            return 
        else:
            logging.info("response recieved from the database updation..")
            logging.info(response)
            return
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def create_alert_parameters(alarm):
    """create parameters for creating the alert

    Args:
        alarm (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        defaults = {
        'type': 'alert',
        'evaluationFrequency': '5m',
        'threshold': 0,
        'metricNamespace': 'defaultNamespace',
        'metricName': 'defaultMetric',
        'operator': 'equals',
        'timeAggregation': 'sum',
        'targetResourceType': 'defaultResourceType',
        'targetResourceRegion': 'defaultRegion'
        }

        alarm_with_defaults = {key: alarm.get(key, default) for key, default in defaults.items()}

        parameters = {
            "type": alarm_with_defaults['type'],
            "apiVersion": "2018-03-01",
            "name": alarm['alarm_name'],
            "location": "global",
            "severity": 3,
            "enabled": True,
            "scopes": [alarm['resource_id']],
            "evaluationFrequency": alarm_with_defaults['evaluationFrequency'],
            "windowSize": alarm.get('windowSize', 'PT5M'), 
            "criteria": {
                "allOf": [
                    {
                        "threshold": alarm_with_defaults['threshold'],
                        "name": "Metric1",
                        "metricNamespace": alarm_with_defaults['metricNamespace'],
                        "metricName": alarm_with_defaults['metricName'],
                        "operator": alarm_with_defaults['operator'],
                        "timeAggregation": alarm_with_defaults['timeAggregation'],
                        "skipMetricValidation": False,
                        "criterionType": "StaticThresholdCriterion"
                    }
                ],
                "odata.type": "Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria"
            },
            "autoMitigate": True,
            "targetResourceType": alarm_with_defaults['targetResourceType'],
            "targetResourceRegion": alarm_with_defaults['targetResourceRegion'],
            "actions": []
        }

        return parameters
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def update_alert(client,cosmos_client,resource_group, req):
    """function to update alerts in the given subscrion

    Args:
        client (_type_): _description_
        resource_group (_type_): _description_
        rule_name (_type_): _description_
        scope (str, optional): _description_. Defaults to """
    try:
        for alarms in req['alarms']:
            query_data =f"""
            SELECT * FROM c WHERE c.alarm_name = '{alarms}'
            """
            logging.info(query_data)
            database = cosmos_client.get_database_client({"id":"alarms"})
            container = database.get_container_client({"id":"Items"})
            response = list(container.query_items(query_data, enable_cross_partition_query=True))[0]
            logging.info("response from databse")
            logging.info(response)
            azure_alert = client.metric_alerts.get(GROUP_NAME, response['id'])
            if response:

                for condition in azure_alert.criteria.all_of:
                    logging.info("inside the azure alert condition all of.")
                    condition.threshold = req['alarm_threshold']
                # Update the metric alert with the modified threshold and severity
                alerts_response  = client.metric_alerts.create_or_update("cloud-monitoring", response['id'], azure_alert)
                logging.info(alerts_response)
                if not alerts_response:
                    logging.info("alerts creation failed for ")
                    logging.info(alarms)
                    return
                else:
                    logging.info("alerts created ..")
                    logging.info(alerts_response)
                    return
            elif not response:
                logging.info("alert updation failed, record not found in the database.")
                return
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())
        
def modify_alarm_conf(alarms):
    parameters = {
        "severity": alarms['priority'],
        "criteria": {
            "additional_properties": [
                {
                    "threshold": alarms['alarm_threshold'],
                }
            ],
            "odata.type": "Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria"
        }
    }
    return parameters

def update_alarm_configuration(cosmos_client,monitor_client, req): 
    """update alarm configuration..

    Args:
        cosmos_client (_type_): _description_
        monitor_client (_type_): _description_
        req (_type_): _description_
    """

    logging.info("inside update configuration..")
    try:
        logging.info(req)
        for key in req:
            azure_alert = monitor_client.metric_alerts.get(GROUP_NAME, key)
            for condition in azure_alert.criteria.all_of:
                logging.info("inside the azure alert condition all of.")
                condition.threshold = req[key]
                # Update the metric alert with the modified threshold and severity
                logging.info("the alert to be updated. is.............................................")
                logging.info(str(azure_alert))
                alerts_response  = monitor_client.metric_alerts.create_or_update("cloud-monitoring", key, azure_alert)
        return "success"
                

    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def update_alert_db(client,req):
    """function to update already availbe alert with updated coniguration.

    Args:
        client (_type_): _description_
        req
        
        """
    query_data ={
        "partition_key":req["id"],
        "item":req['id']
    }
    try:
        response = get_record(client,"alarms",query_data)
        if response:
            update_record(client,"alarms",response, req['ue'], req['eav'])
        else:
            logging.info("update record failed, record not found for")
            logging.info(req["id"])
            return
    except Exception:
        post_slack(
            "secret", 'Failed with the error', traceback.format_exc())
        
def delete_alert(monitor_client, cosmos_client, req):
    """function to delete a specific alert from the given subscription.

    Args:
        monitor_client (_type_): _description_
        cosmos_client (_type_): _description_
        req (_type_): _description_
    """
    alarms=[]
    logging.info("inside alert delete function..")
    logging.info(req)
    try:
        for alarm in req['alarms']:
            query_data = f"SELECT * FROM c WHERE c.alarm_name = '{alarm['id']}'"
            logging.info(query_data)
            database = cosmos_client.get_database_client({"id":"alarms"})
            container = database.get_container_client({"id":"Items"})
            response = list(container.query_items(query_data, enable_cross_partition_query=True))
            logging.info("the response from database..")
            logging.info(response)

            if response:
                alarms.append(response[0])
            else:
                logging.info("alarm not forund for id")
                logging.info(alarm['id'])
        logging.info("delete alarm list..")
        logging.info(alarms)
        for alarm in alarms:

            response = monitor_client.metric_alerts.delete(
                resource_group_name =GROUP_NAME,
                rule_name= alarm['id']
            )
            record ={
            "partition_key":alarm["id"],
            "item":alarm['id']
            }
            alarm['is_deleted'] = True
            alarm = {k: v for k, v in alarm.items() if not k.startswith('_')}
            logging.info("inside update mehthod..")
            logging.info(alarm)
            database = cosmos_client.get_database_client({"id":"alarms"})
            container = database.get_container_client({"id":"Items"})
            response = container.upsert_item(alarm)
            # delete_record(cosmos_client,"alarms", record)

        if response:
            logging.info("alerts deleted ..")
            logging.info(response)
            return
    except Exception:
            post_slack(
            "secret", 'Failed with the error', traceback.format_exc())

def delete_account(monitor_client, cosmos_client, req):
    """function to delete an account from cloudmonitoring.

    Args:
        monitor_client (_type_): _description_
        cosmos_client (_type_): _description_
        req (_type_): _description_
    """
    alarms=[]
    try:
        for alarm in req['alarms']:
            query_data ={
            "partition_key":alarm["id"],
            "item":alarm['id']
            }
            response = get_record(cosmos_client,"alarms", query_data)
            if response:
                alarms.append(response)
            else:
                logging.info("alarm not forund for id")
                logging.info(alarm['id'])

        for alarm in alarms:
            response = monitor_client.metric_alerts.delete(
                resource_group_name =GROUP_NAME,
                rule_name= alarm['resource_id']
            )
            record ={
            "partition_key":alarm["id"],
            "item":alarm['id']
            }
            delete_record(cosmos_client,"alarms", record)
        if response:
            logging.info("alerts deleted ..")
            logging.info(response)
            return
    except Exception:
            post_slack(
            "secret", 'Failed with the error', traceback.format_exc())
 
def call_put_alarm(blob):
    """function to call cm-app-alert function with required parameters.

    Args:
        vm_list (_type_): _description_
    """
    try:
        headersAuth = {
        'Authorization': put_alarm_function_key} # will remove this later. once managed identity is implemented.
        response = requests.post(url=put_alarm_no_token,json={"req":{"blob":blob}})
        logging.info("Info: app alert function called..")
        logging.info(response)
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def create_alert(client, req):
    """create alert in the current subsctiption.

    Args:
        client (_type_): _description_
        req (_type_): _description_
    """

    try:
        parameters = create_alert_parameters(req)

        alerts = client.metric_alerts.create_or_update(
                resource_group_name =GROUP_NAME,
                rule_name=req['rule_name'],
                parameters=parameters
            )

        if not alerts:
            logging.info("alerts creation failed for ")
            logging.info(req["id"])
            return
        else:
            logging.info("alerts created ..")
            logging.info(alerts)
            return
    except Exception:
        post_slack(
            "secret", 'Failed toread item the error', traceback.format_exc())
        
def get_record(client,database_id, data):
    """function to fetch a specific record from database.

    Args:
        container (_type_): _description_
        item (_type_): _description_
        client (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        database = client.get_database_client({"id":database_id})
        container = database.get_container_client({"id":"Items"})

        response = container.read_item(item=data["item"], partition_key=data["partition_key"])
        if not response:
            logging.info("request didnt processed")
            return
        else:
            logging.info(response)
            return response
    except Exception:
            post_slack(
            "secret", 'Failed toread item the error', traceback.format_exc())

def insert_to_blobstorage(blob_client, blob_container, data):
    """function to insert azure item paged data to azure blob storage.

    Args:
        blob_client (_type_): _description_
        blob_container (_type_): _description_
        data (_type_): _description_

    Returns:
        _type_: _description_
    """
    try:
        container = blob_client.get_container_client(blob_container)
        blob_name = "cloud_monitoring-test" + str(random.random()) # test name wchich adds a random number as suffix.
        response = container.upload_blob(name=blob_name,data=json.dumps(data, cls=DecimalEncoder))
        logging.info("Info: Insert into Blob response")
        logging.info(response)
        return (response, blob_name)
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def call_app_list_alarms(subscription_id, path=None,type=None):
    """calls external function : cm-app-list-services

    Args:
        path (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """

    logging.info('in cm-app-list-services call:-')
    try:
        headersAuth = {
        'Authorization': app_list_function_key} # will remove this later. once managed identity is implemented.
        response = requests.post(url=app_list_services,json={"req":{"path":path,"type":type, "subscription_id":subscription_id}})

        return response
    except Exception:
        post_slack(
                "secret", 'Process Failed with the error', traceback.format_exc())

def post_slack(secret, msg, e):
    """function pushes errors to slack as a part of user notification.

    Args:
        secret (_type_): _description_
        msg (_type_): _description_
        e (_type_): _description_
    """
    # print('Error:' if e else 'Info:', msg, e)
    # url = secret.get('slack_url')
    # headers = {
    #     'x-api-key':  secret.get('slack_key'),
    #     'content-type': 'application/json'
    # }

    # pld = {
    #     'status': 'failed' if e else 'ok',
    #     'impacted_area': f'{os.environ.get("FUNCTION")} || {msg}',
    #     'description': str(e),
    #     'slack': secret.get('slack_channel'),
    #     'dpe_division': 'des'
    # }
    # r = requests.post(url, data=json.dumps(pld), headers=headers)
    # print('Info: Error posted to slack', r.status_code)
    print("the error raised. ",e)
   
class DecimalEncoder(json.JSONEncoder):
    """Class for converting ItemPaged object to json.

    Args:
        json (_type_): _description_
    """
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.timestamp()
        return obj.__dict__
